package example;

import com.caucho.hessian.client.HessianProxyFactory;

public class BasicClient {
  public static void main(String []args)
    throws Exception
  {
    String url = "http://localhost:1234/HelloWorldProject/hello";

    HessianProxyFactory factory = new HessianProxyFactory();
    GreetingAPI basic = (GreetingAPI) factory.create(GreetingAPI.class, url);

    System.out.println("Hello: " + basic.hello());
  }
}
