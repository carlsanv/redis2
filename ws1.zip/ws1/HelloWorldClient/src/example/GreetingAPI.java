package example;

public interface GreetingAPI {
	  public String hello();
	}