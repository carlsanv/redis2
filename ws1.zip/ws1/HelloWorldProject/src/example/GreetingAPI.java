package example;

import java.io.File;

public interface GreetingAPI {
	  public String hello();
	  
	
	}